from django.contrib import admin
from .models import Lyric

admin.site.register(Lyric)
