from django.contrib import admin
from .models import Artiste

admin.site.register(Artiste)
